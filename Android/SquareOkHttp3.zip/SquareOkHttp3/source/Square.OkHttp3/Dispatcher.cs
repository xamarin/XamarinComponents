namespace Square.OkHttp3
{
    partial class Dispatcher
    {
        public void SetIdleCallback(Java.Lang.IRunnable idleCallback) =>
            IdleCallback = idleCallback;
    }
}
